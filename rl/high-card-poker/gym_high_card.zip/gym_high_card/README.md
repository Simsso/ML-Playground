# High-Card Gym

Two or more players are given a card and they can play normal poker (bet, fold, raise, check).
Showdown takes place after the first betting round and the player with the highest card gets the pot.
If players have cards of equal rank, the pot is split between them. 