from setuptools import setup

setup(name='gym_high_card',
      version='0.0.1',
      install_requires=['gym']  # dependencies of gym_high_card
)